(function($) {
	$('#slides').slides({
		preload: true,
		preloadImage: 'images/xm-slide/loading.gif',
		play: 5000,
		pagination: false,
		pause: 2500,
		hoverPause: true
	});
})(jQuery);

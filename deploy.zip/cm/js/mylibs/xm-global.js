xmGlobal = {
	xmOverlay : $('#xm-overlay-div')
};
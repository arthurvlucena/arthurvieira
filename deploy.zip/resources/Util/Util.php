<?php
function isEmpty($var) {
	return $var."" == "";
}

function isNotEmpty() {
	return $var."" != "";
}
?>